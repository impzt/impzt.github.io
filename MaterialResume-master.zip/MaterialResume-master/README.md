# MaterialResume
A example of Material Resume

### Mockup
![alt mockup](./mockup.jpg)

Made with [Sketch](http://bohemiancoding.com/sketch/)

### Example

[stankocken.com/cv](http://www.stankocken.com/cv)